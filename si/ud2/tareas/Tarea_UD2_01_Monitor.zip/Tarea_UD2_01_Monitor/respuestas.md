# Respuestas

## 1. Procesos: comandos y resultados

## 3. Cron: comandos y dos líneas del registro

## 4. Systemd: comandos y preguntas
