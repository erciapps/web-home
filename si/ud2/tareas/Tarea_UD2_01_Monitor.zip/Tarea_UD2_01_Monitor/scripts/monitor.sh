#!/bin/bash

printf 'ud2monitor' > /proc/$$/comm

while [[ true ]];do
    sleep 2
done
