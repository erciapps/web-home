#!/bin/bash

# TODO: buscar el proceso ud2monitor por su nombre exacto.

# TODO: comprobar el resultado y mostrar si está en ejecución o detenido.
