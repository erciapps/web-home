#!/bin/bash

# TODO: buscar el proceso ud2monitor por su nombre exacto.

# TODO: si existe, detenerlo y mostrar un mensaje.
# Si no existe, informar de ello.
