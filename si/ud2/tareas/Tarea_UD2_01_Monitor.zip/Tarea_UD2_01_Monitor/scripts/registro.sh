#!/bin/bash

FICHERO="$(dirname "$0")/../ejecuciones.log"

# TODO: añadir la fecha y hora a FICHERO sin borrar el contenido anterior.
