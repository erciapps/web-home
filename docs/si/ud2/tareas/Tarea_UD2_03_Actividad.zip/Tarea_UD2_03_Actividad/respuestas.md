# Respuestas

## 1. Procesos: comandos y resultados

## 3. Cron: comandos y dos ejecuciones completas del registro

## 4. Systemd: comandos y preguntas
