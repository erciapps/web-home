#!/bin/bash

printf 'ud2actividad' > /proc/$$/comm

while [[ true ]];do
    sleep 2
done
