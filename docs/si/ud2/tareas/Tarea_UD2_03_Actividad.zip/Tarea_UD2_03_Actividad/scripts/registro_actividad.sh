#!/bin/bash

FICHERO="$(dirname "$0")/../actividad.log"

# TODO: añadir la fecha y hora actuales y, en la línea siguiente, la salida de `uptime` a FICHERO sin borrar el contenido anterior.
