#!/bin/bash

# TODO: buscar el proceso ud2actividad por su nombre exacto.

# TODO: comprobar el resultado del comando anterior.
# Si existe, mostrar un mensaje.
# Si no existe, ejecutar scripts/actividad.sh con bash en segundo plano
# y mostrar su PID.
