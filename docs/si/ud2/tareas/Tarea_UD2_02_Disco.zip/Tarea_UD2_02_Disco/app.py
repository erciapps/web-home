from flask import Flask, render_template, request
from crontab import CronTab
import subprocess
from pathlib import Path

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent


@app.route("/")
def inicio():
    return render_template("index.html")


@app.route("/proceso", methods=["POST"])
def proceso():
    proceso = request.form["proceso"]
    accion = request.form["accion"]
    script = None

    if proceso == "disco":
        if accion == "iniciar":
            pass  # TODO: asignar el script de inicio
        elif accion == "estado":
            pass  # TODO: asignar el script de estado
        elif accion == "detener":
            pass  # TODO: asignar el script de parada

    if script is None:
        return render_template("index.html", mensaje="Proceso no encontrado")

    # TODO: ejecutar el script con subprocess.run(), Bash, cwd=BASE_DIR,
    # capture_output=True y text=True. Guardar el resultado.

    # TODO: enviar resultado.stdout a la plantilla.
    return render_template("index.html", mensaje="Pendiente de completar")


@app.route("/tareacron", methods=["POST"])
def tarea():
    frecuencia = request.form["frecuencia"]
    if frecuencia not in ("1", "3", "15"):
        return render_template("index.html", mensaje="Frecuencia no válida")

    cron = CronTab(user=True)
    tarea = cron.new(
        command=f'bash "{BASE_DIR}/scripts/registro_disco.sh"',
        comment="TAREA-DISCO"
    )

    if frecuencia == "1":
        pass  # TODO: configurar la frecuencia
    elif frecuencia == "3":
        pass  # TODO: configurar la frecuencia
    elif frecuencia == "15":
        pass  # TODO: configurar la frecuencia

    # TODO: guardar la tarea programada.
    return render_template("index.html", mensaje="Pendiente de completar")


if __name__ == "__main__":
    app.run()
