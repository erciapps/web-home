#!/bin/bash

FICHERO="$(dirname "$0")/../disco.log"

# TODO: añadir la fecha y hora actuales y, en la línea siguiente, la salida de `df -h /` a FICHERO sin borrar el contenido anterior.
