#!/bin/bash

printf 'ud2disco' > /proc/$$/comm

while [[ true ]];do
    sleep 2
done
